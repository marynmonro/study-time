import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("k:"); // 6.1;3.5;1.4;0.2
        String k = in.nextLine();
        System.out.println("train-set:"); //train-set.csv
        String trainSetPath = in.nextLine();
        System.out.println("test-set:"); //test-set.csv
        String testSetPath = in.nextLine();

        KNN.TestSetKNN(new Data(trainSetPath, testSetPath));
        System.out.println(" - - - ");
        KNN.TestArgumentKNN(new Data(trainSetPath), new Iris(k));
    }
}